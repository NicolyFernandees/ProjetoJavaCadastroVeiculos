public interface OperacoesVeiculo {
    void realizarManutencao();
}
